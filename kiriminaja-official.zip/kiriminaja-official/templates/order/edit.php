<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * @var string $orderId
 * @var string $trackingUrl
 * @var string $kiriofOrderData
 */
?>
<?php
ob_start();
?>
jQuery(function ($) {
    kiriofGetTransactionData();
});

function kiriofGetTransactionData() {
    let orderId = <?php echo wp_json_encode( (string) $orderId ); ?>;
    let trackingUrl = <?php echo wp_json_encode( (string) $trackingUrl ); ?>;
    let kiriofOrderData = <?php echo wp_json_encode( (string) $kiriofOrderData ); ?>;

    let kiriofOrderDataParsed = JSON.parse(kiriofOrderData);

    let label_ppn = '11%';
    let tBodycontent = '';

    jQuery('#side-sortables').append(`
<div id="woocommerce-customer-history" class="postbox ">
   <div class="postbox-header">
      <h2 class="hndle ui-sortable-handle">Shipping</h2>
      <div class="handle-actions hide-if-no-js"><button type="button" class="handle-order-higher" aria-disabled="false" aria-describedby="woocommerce-customer-history-handle-order-higher-description"><span class="screen-reader-text">Move up</span><span class="order-higher-indicator" aria-hidden="true"></span></button><span class="hidden" id="woocommerce-customer-history-handle-order-higher-description">Move Customer history box up</span><button type="button" class="handle-order-lower" aria-disabled="false" aria-describedby="woocommerce-customer-history-handle-order-lower-description"><span class="screen-reader-text">Move down</span><span class="order-lower-indicator" aria-hidden="true"></span></button><span class="hidden" id="woocommerce-customer-history-handle-order-lower-description">Move Customer history box down</span><button type="button" class="handlediv" aria-expanded="true"><span class="screen-reader-text">Toggle panel: Customer history</span><span class="toggle-indicator" aria-hidden="true"></span></button></div>
   </div>

   <div class="inside">
    <!--Content-->
    <table id="kj-order-edit-shipping" style="width: 100%">
        <tbody>
            <tr>
                <th>Order ID <span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.order_id}</td>
            </tr>
            <tr>
                <th>Pickup ID <span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.pickup_id}</td>
            </tr>
            <tr>
                <th>Payment <span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.payment_type}</td>
            </tr>
            <tr>
                <th>Service <span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.service}</td>
            </tr>
            <tr>
                <th>AWB <span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.awb}</td>
            </tr>
            <tr>
                <th>Status <span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.status}</td>
            </tr>
            <tr>
                <th>Shipping Cost <span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.shipping_cost}</td>
            </tr>
            `
            +
            /** COD ROW */
            (
            kiriofOrderDataParsed?.cod_fee !=='-'
            ?    
             `
            <tr>
                <th>
                    COD Fee <span style="margin-left: auto">:</span>
                    <br/>
                    <em style="font-weight: 500;font-size:12px;">(Include `+label_ppn+` Vat)</em>
                </th>
                <td>${kiriofOrderDataParsed?.cod_fee}</td>
            </tr>
            `   
             :
            ``
            )
            +
            /** Insurance ROW */
            (
            kiriofOrderDataParsed?.insurance_fee !=='-'
                ?
                `
            <tr>
                <th>Insurance Fee <span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.insurance_fee}</td>
            </tr>
            `
                :
                ``
            )
            +
            `
            <tr>
                <th>Order Total<span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.transaction_value}</td>
            </tr>
            <tr>
                <th>Total <span style="margin-left: auto">:</span></th>
                <td>${kiriofOrderDataParsed?.total}</td>
            </tr>
        </tbody>
    </table>
   </div>
    <!--BTN-->

    <div class="add_note" style="padding: 10px">
        <div style="display: relative">
            <button type="button" style="width: 100%" class="button save_order button button-primary" name="save" value="Update">Shipment Tracker</button>        
            <a href="${trackingUrl}" target="_blank" style="position: absolute; top: 0;left: 0;bottom: 0;right: 0"></a>
        </div>
    </div>
</div>
        `)

}
<?php
$kiriof_inline_script = ob_get_clean();

wp_add_inline_script( 'jquery', $kiriof_inline_script );
?>