<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * @var string $locale
 * @var array $inputValueArr
 */
?>
<div class="wrap kj-wrap">

    <?php $kiriof_title = __( 'KiriminAja Configuration', 'kiriminaja-official' ); include KIRIOF_DIR . 'templates/_header.php'; ?>
    <hr class="wp-header-end">

                        <div style="max-width: 437px; width: 100%; margin: 0 auto">

                            
                            <!--CARD START-->
                            <div style="margin-top: 5vh"></div>
                            <div class="kj-card">
                                                    <!--CARD CONTENT-->
                                                    <div style="text-align: center">
                                                        <!--Logos-->
                                                        <div style="display: flex">
                                                            <div style="margin: auto">
                                                                <div style="display: flex;align-items: center">
                                                                    <div>
                                                                        <svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                            <g clip-path="url(#clip0_26_7208)">
                                                                                <path d="M32.5 16C32.5 7.168 25.332 0 16.5 0C7.668 0 0.5 7.168 0.5 16C0.5 24.832 7.668 32 16.5 32C25.332 32 32.5 24.832 32.5 16ZM16.5 1.616C24.452 1.616 30.884 8.048 30.884 16C30.884 23.952 24.452 30.384 16.5 30.384C8.548 30.384 2.116 23.952 2.116 16C2.116 8.048 8.548 1.616 16.5 1.616ZM13.316 23.712L8.436 10.576C9.22 10.528 10.116 10.448 10.116 10.448C10.804 10.368 10.724 8.832 10.02 8.864C10.02 8.864 7.956 9.024 6.612 9.024C6.372 9.024 6.084 9.024 5.78 9.008C8.084 5.536 12.02 3.248 16.5 3.248C19.844 3.248 22.884 4.512 25.156 6.592C24.196 6.464 22.836 7.152 22.836 8.864C22.836 9.92 23.444 10.816 24.1 11.872C24.596 12.736 24.9 13.824 24.9 15.408C24.9 17.552 22.868 22.576 22.868 22.576L18.532 10.576C19.3 10.528 19.732 10.32 19.732 10.32C20.42 10.24 20.34 8.56 19.652 8.592C19.652 8.592 17.572 8.768 16.228 8.768C14.98 8.768 12.852 8.592 12.852 8.592C12.164 8.56 12.084 10.288 12.772 10.32L14.116 10.448L15.908 15.312L13.316 23.712ZM22.948 27.152L27.124 16C27.124 16 28.196 13.296 27.748 9.904C28.756 11.728 29.252 13.776 29.252 16C29.252 20.736 26.756 24.928 22.948 27.152ZM4.788 10.832L10.9 27.6C6.628 25.52 3.748 21.072 3.748 16C3.748 14.144 4.068 12.432 4.788 10.832ZM16.708 18.08L20.372 28.08C19.172 28.512 17.86 28.752 16.5 28.752C15.348 28.752 14.244 28.576 13.204 28.272L16.708 18.08Z" fill="black"/>
                                                                            </g>
                                                                            <defs>
                                                                                <clipPath id="clip0_26_7208">
                                                                                    <rect width="32" height="32" fill="white" transform="translate(0.5)"/>
                                                                                </clipPath>
                                                                            </defs>
                                                                        </svg>
                                                                    </div>
                                                                    <div style="margin: 0 .5rem">
                                                                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                            <path d="M5.44016 8.93999L4.50016 7.99999L1.8335 10.6667L4.50016 13.3333L5.44016 12.3933L4.38683 11.3333H14.5002V9.99999H4.38683L5.44016 8.93999Z" fill="black"/>
                                                                            <path d="M11.5602 7.05999L12.5002 7.99999L15.1668 5.33332L12.5002 2.66666L11.5602 3.60666L12.6135 4.66666H2.50016V5.99999H12.6135L11.5602 7.05999Z" fill="black"/>
                                                                        </svg>
                                                                    </div>
                                                                    <div>
                                                                        <svg width="35" height="34" viewBox="0 0 35 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.0462 31.1464L9.99204 27.6756L6.09621 26.8256C5.74204 26.7548 5.45869 26.5717 5.24619 26.2766C5.03369 25.9814 4.95104 25.6568 4.99827 25.3027L5.38787 21.3006L2.73161 18.2548C2.49549 17.9949 2.37744 17.6881 2.37744 17.3339C2.37744 16.9798 2.49549 16.6728 2.73161 16.4131L5.38787 13.3673L4.99827 9.36519C4.95104 9.01102 5.03369 8.68638 5.24619 8.39123C5.45869 8.0961 5.74204 7.91311 6.09621 7.84227L9.99204 6.99227L12.0462 3.52144C12.2351 3.2145 12.4948 3.0079 12.8254 2.90165C13.1559 2.7954 13.4865 2.81311 13.817 2.95477L17.5004 4.51311L21.1837 2.95477C21.5142 2.81311 21.8449 2.7954 22.1754 2.90165C22.5059 3.0079 22.7657 3.2145 22.9545 3.52144L25.0087 6.99227L28.9045 7.84227C29.2587 7.91311 29.542 8.0961 29.7545 8.39123C29.967 8.68638 30.0496 9.01102 30.0024 9.36519L29.6129 13.3673L32.2691 16.4131C32.5053 16.6728 32.6233 16.9798 32.6233 17.3339C32.6233 17.6881 32.5053 17.9949 32.2691 18.2548L29.6129 21.3006L30.0024 25.3027C30.0496 25.6568 29.967 25.9814 29.7545 26.2766C29.542 26.5717 29.2587 26.7548 28.9045 26.8256L25.0087 27.6756L22.9545 31.1464C22.7657 31.4533 22.5059 31.66 22.1754 31.7662C21.8449 31.8725 21.5142 31.8548 21.1837 31.7131L17.5004 30.1548L13.817 31.7131C13.4865 31.8548 13.1559 31.8725 12.8254 31.7662C12.4948 31.66 12.2351 31.4533 12.0462 31.1464ZM14.3138 11.8384C14.0908 11.5916 14.2369 11.1808 14.564 11.1117L21.2603 9.57231C21.5874 9.50326 21.8671 9.81114 21.7641 10.1258L19.7437 16.3751C19.6407 16.6909 19.232 16.7758 19.0078 16.5301L18.2087 15.73L16.8075 17.1165V17.1213L20.871 21.1857C21.7392 22.054 21.7471 23.4021 20.8971 24.2441C20.047 25.0864 18.7204 25.0444 17.8578 24.1819L16.8075 23.1362V23.1428L12.9444 19.2905L12.2877 18.6367C12.2476 18.5969 12.2093 18.5559 12.1728 18.5137C11.3535 17.5925 11.4512 16.4732 12.0995 15.6947C12.1456 15.6379 12.1951 15.5832 12.2481 15.5307C12.2626 15.5163 12.2772 15.5023 12.2919 15.4886L15.1446 12.6692L14.3138 11.8384Z" fill="#782B8F"/>
                                                                        </svg>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div style="margin-top: .5rem"></div>
                                                        <div style="font-weight: 700"><?php echo esc_html(__( 'Connect Wordpress to KiriminAja', 'kiriminaja-official' )); ?></div>
                                                    </div>
                                                    <div class="row-divider"></div>
                                                    <div>
                                                        <div><?php echo esc_html(__( 'Connect to KiriminAja Application by Input the setup key', 'kiriminaja-official' )); ?></div>
                                                        <div style="margin-top: .5rem"></div>
                                                        <div style="font-weight: 700"><?php echo esc_html(__( 'Plugin Features', 'kiriminaja-official' )); ?></div>
                                                        <div style="margin-top: .5rem"></div>
                                                        <ul class="default">
                                                            <li><?php echo esc_html(__( 'Indonesian 3PL Integrations', 'kiriminaja-official' )); ?></li>
                                                            <li><?php echo esc_html(__( 'Cash on Delivery Support', 'kiriminaja-official' )); ?></li>
                                                            <li><?php echo esc_html(__( 'Realtime Tracking', 'kiriminaja-official' )); ?></li>
                                                        </ul>
                                                    </div>

                                                    <div class="row-divider"></div>
                                                    <div id="setup-form">
                                                        <!--INPUT-->
                                                        <div>
                                                            <div><?php esc_html_e( 'Setup Key (Secret)', 'kiriminaja-official' ); ?></div>
                                                            <div style="margin-top: .5rem"></div>
                                                            <div>
                                                                <input style="width: 100%; max-width: 25rem" name="setup_key" type="text" class="input-text regular-input" placeholder="<?php echo esc_attr(__( 'Put your setup key here', 'kiriminaja-official' )); ?>..." value="">
                                                            </div>
                                                        </div>
                                                        
                                                        <!--ALERT-->
                                                        <div class="alert kj-hidden" style="margin-top: .5rem">
                                                            <div style="display: flex">
                                                                <svg style="position: relative; top: 2px" width="16" height="16" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M6.99961 0.600006C10.5356 0.600006 13.3996 3.46401 13.3996 7.00001C13.3996 10.536 10.5356 13.4 6.99961 13.4C3.46361 13.4 0.599609 10.536 0.599609 7.00001C0.599609 3.46401 3.46361 0.600006 6.99961 0.600006ZM7.90361 8.10401L8.18361 2.93601H5.81561L6.09561 8.10401H7.90361ZM7.83161 10.792C8.02361 10.608 8.12761 10.352 8.12761 10.024C8.12761 9.68801 8.03161 9.43201 7.83961 9.24801C7.64761 9.06401 7.36761 8.96801 6.99161 8.96801C6.61561 8.96801 6.33561 9.06401 6.13561 9.24801C5.93561 9.43201 5.83961 9.68801 5.83961 10.024C5.83961 10.352 5.94361 10.608 6.14361 10.792C6.35161 10.976 6.63161 11.064 6.99161 11.064C7.35161 11.064 7.63161 10.976 7.83161 10.792Z" fill="#D63638"/>
                                                                </svg>
                                                                <div style="margin-left: 8px">
                                                                    <div>
                                                                        <span style="font-weight: 600"><?php echo esc_html__( 'Error', 'kiriminaja-official' ); ?></span>
                                                                    </div>
                                                                    <div>
                                                                        <span class="msg"><?php echo esc_html__( 'Invalid setup key, please try another key please', 'kiriminaja-official' ); ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <!--BTN GROUP-->
                                                        <div class="row-divider"></div>
                                                        <div class="kj-btn-group" style="display: flex; gap: 8px">
                                                            <button class="button button-primary kj-submit" type="button">
                                                                <span class="dashicons dashicons-admin-links" style="vertical-align: middle; margin-right: 4px"></span>
                                                                <?php echo esc_html(__( 'Connect Now', 'kiriminaja-official' )); ?>
                                                            </button>
                                                            <div style="position: relative">
                                                                <button class="button button-secondary" type="button"><?php echo esc_html( __( 'How to Connect', 'kiriminaja-official' ) ); ?></button>
                                                                <a class="kj-absolute-center" href="https://help.kiriminaja.com/article/setup-wordpress" target="_blank"></a>
                                                            </div>
                                                        </div>
                                                        <div class="kj-loader kj-hidden" style="margin: auto"></div>
                                                    </div>

                            <!--CARD END-->
                            </div>
                        </div>
</div>

<!--Integration-->
<?php ob_start(); ?>

    /** Integration AJAX*/
    /*** Submit DATA*/
    jQuery('body').on('click', '#setup-form .kj-submit', function(e) {
        jQuery('#setup-form .alert').addClass('kj-hidden')
        jQuery('#setup-form .kj-btn-group').addClass('kj-hidden')
        jQuery('#setup-form .kj-loader').removeClass('kj-hidden')
                
        jQuery.ajax({
            type: "post",
            url: kiriofAjaxRoute(),
            data: {
                action: "kiriof_store_integration_data",  // the action to fire in the server
                data: {
                    setup_key:jQuery('#setup-form [name="setup_key"]').val(),
                    nonce : kiriofAjax.nonce      
                },         // any JS object
            },
            complete: function (response) {
                const resp = JSON.parse(response.responseText).data;
                if (resp?.status === 200){
                    window.location.reload()
                    return
                }
                
                jQuery('#setup-form .alert').removeClass('kj-hidden')
                jQuery('#setup-form .alert .msg').text(resp.message)

                jQuery('#setup-form .kj-btn-group').removeClass('kj-hidden')
                jQuery('#setup-form .kj-loader').addClass('kj-hidden')
            },
        });
    });

<?php
$kiriof_inline_script = ob_get_clean();
wp_add_inline_script( 'kiriof-script', $kiriof_inline_script );
?>