<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if ( ! current_user_can( 'manage_woocommerce' ) ) {
    wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'kiriminaja-official' ) );
}


// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Template class for request pickup functionality
class Kiriof_RequestPickupIndex {
    function __construct(){
        /** WP Setting language*/
        $locale = get_locale();
        
        /** Page Query*/
        // @codingStandardsIgnoreLine
        $pageQuery = self::pageQuery();
        $results = $pageQuery['results'];
        $page = $pageQuery['page'];
        $items_per_page = $pageQuery['items_per_page'];
        $total_pages = $pageQuery['total_pages'];
        $next_page_link = $pageQuery['next_page_link'];
        $prev_page_link = $pageQuery['prev_page_link'];

        /** Month Options*/
        $monthOptions = self::getPaymentsDateFilterOptionArray();
        (new \KiriminAjaOfficial\Base\BaseInit())->logThis('$monthOptions',[$monthOptions]);

        /**
         * Status filter counts (powers the "All / Waiting for Payment / Paid"
         * pill row in view/index.php). Always computed against the full table
         * so the totals stay stable regardless of which pill is currently
         * selected — same UX as WooCommerce's order list.
         */
        $kiriof_paymentRepo = new \KiriminAjaOfficial\Repositories\PaymentRepository();
        $kiriof_statusCounts = [
            'all'    => $kiriof_paymentRepo->getCountByStatus( null ),
            'unpaid' => $kiriof_paymentRepo->getCountByStatus( 'unpaid' ),
            'paid'   => $kiriof_paymentRepo->getCountByStatus( 'paid' ),
        ];

        /** Return vars and view*/
        include 'view/index.php';
    }
    
    private function pageQuery(){
        global $wpdb;
        
        /** Tables*/
        $paymentTable = $wpdb->prefix . 'kiriminaja_payments';
        $transactionTable = $wpdb->prefix . 'kiriminaja_transactions';

        /** PreRequrities*/
        $items_per_page = 20;

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['cpage']) ? max( 1, absint($_GET['cpage']) ) : 1;
        
        $whereConditions = [];
        
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!empty(sanitize_text_field(wp_unslash($_GET['key'] ?? '')))) {
            $key = sanitize_text_field(wp_unslash($_GET['key'])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $whereConditions[] = $wpdb->prepare("kiriminaja_payments.pickup_number LIKE %s", '%' . $wpdb->esc_like($key) . '%');
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!empty(sanitize_text_field(wp_unslash($_GET['month'] ?? '')))) {
            $month = sanitize_text_field(wp_unslash($_GET['month'])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $whereConditions[] = $wpdb->prepare("kiriminaja_payments.created_at LIKE %s", '%' . $wpdb->esc_like($month) . '%');
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $status = sanitize_text_field(wp_unslash($_GET['status'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( in_array( $status, array( 'unpaid', 'paid' ), true ) ) {
            $whereConditions[] = $wpdb->prepare("kiriminaja_payments.status = %s", $status);
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Each condition is individually prepared above
        $whereCondition = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

        /** Pagination Query*/
        $count_sql = "SELECT 
            kiriminaja_payments.id, kiriminaja_payments.pickup_number
            FROM {$wpdb->prefix}kiriminaja_payments as kiriminaja_payments
            INNER JOIN {$wpdb->prefix}kiriminaja_transactions as kiriminaja_transactions
            ON kiriminaja_payments.pickup_number = kiriminaja_transactions.pickup_number
            " . $whereCondition . "
            GROUP BY kiriminaja_payments.pickup_number";

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query safe: whereCondition contains pre-prepared statements, no additional params needed
        $totalQuery = $wpdb->get_results($count_sql);
        $total = count($totalQuery);
        $total_pages = (int) ceil($total/$items_per_page);
        if ( $page > $total_pages && $total_pages > 0 ) {
            $page = $total_pages;
        }
        $offset = ( $page - 1 ) * $items_per_page;

        /** Main Query*/
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names use prefix, whereCondition pre-prepared above
        $baseQuery = "SELECT
            kiriminaja_payments.*,
            SUM(CASE WHEN kiriminaja_transactions.cod_fee = 0 THEN kiriminaja_transactions.shipping_cost - COALESCE(kiriminaja_transactions.discount_amount, 0) + kiriminaja_transactions.insurance_cost ELSE 0 END) AS cost
            FROM {$wpdb->prefix}kiriminaja_payments as kiriminaja_payments
            INNER JOIN {$wpdb->prefix}kiriminaja_transactions as kiriminaja_transactions
            ON kiriminaja_payments.pickup_number = kiriminaja_transactions.pickup_number
            " . $whereCondition . "
            GROUP BY kiriminaja_payments.pickup_number
            ORDER BY kiriminaja_payments.created_at DESC
            LIMIT %d, %d";

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $results = $wpdb->get_results(
            $wpdb->prepare($baseQuery, $offset, $items_per_page) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        );

        if (strlen(@$wpdb->last_error ?? '') > 0){
            (new \KiriminAjaOfficial\Base\BaseInit())->logThis('last_error',@$wpdb->last_error);
        }

        /** Paginate*/
        $next_page_link = admin_url( 'admin.php?' );
        $prev_page_link = admin_url( 'admin.php?' );
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Pagination link building from GET params
        foreach ($_GET as $key => $value){
            if ($key !== 'cpage'){
                $next_page_link .= sanitize_key($key) . '=' . urlencode(sanitize_text_field(wp_unslash($value))) . '&';
                $prev_page_link .= sanitize_key($key) . '=' . urlencode(sanitize_text_field(wp_unslash($value))) . '&';
            }
        }
        $next_page_link= $page+1<=$total_pages ? esc_url($next_page_link.'cpage='.($page+1)) : '';
        $prev_page_link= $page-1>0 ? esc_url($prev_page_link.'cpage='.($page-1)) : '';
        
        return [
            'results'=>$results,
            'page'=>$page,
            'items_per_page'=>$items_per_page,
            'total_pages'=>$total_pages,
            'next_page_link'=>$next_page_link,
            'prev_page_link'=>$prev_page_link
        ];
        
    }
    
    private function getPaymentsDateFilterOptionArray(){
        $oldestPaymentDateQuery = (new \KiriminAjaOfficial\Repositories\PaymentRepository())->getPaymentByOldestDate();
        $oldestMonth= gmdate('Y-m-d',strtotime($oldestPaymentDateQuery->created_at ?? "now"));
        $currentMonth = gmdate('Y-m-d',strtotime("now"));
        $d1=new DateTime($oldestMonth);
        $d2=new DateTime($currentMonth);
        $Months = $d2->diff($d1);
        $howeverManyMonths = ((($Months->y) * 12) + ($Months->m)+1);
        $monthOptions = [];
        for($i=0;$i<=$howeverManyMonths;$i++){
            $theDate = "now"."-".$i." months";
            $monthOptions[gmdate('Y-m',strtotime($theDate))]=gmdate('Y F',strtotime($theDate));
        }
        return $monthOptions;
    }
}
new Kiriof_RequestPickupIndex();

?>
