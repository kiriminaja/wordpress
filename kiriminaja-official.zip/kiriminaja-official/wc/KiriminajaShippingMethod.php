<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create Shipping Method Kiriminaja
 * --------------------------------
 * Admin Setting
 */
add_action('woocommerce_shipping_init', 'kiriof_shipping_method',99);
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Required for WooCommerce action callback
function kiriof_shipping_method(){
    if (!class_exists('Kiriof_Shipping_Method_Controller')) {
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- WooCommerce shipping method class
        class Kiriof_Shipping_Method_Controller extends WC_Shipping_Method
        {
            private const KIRIOF_MIN_ADDRESS_LENGTH = 10;

            public function __construct( $instance_id = 0 ){
                
                $this->id = 'kiriminaja-official';
                $this->instance_id = absint( $instance_id );
                $this->method_title = __('KiriminAja', 'kiriminaja-official');
                $this->method_description = __('KiriminAja real-time shipping rates for this shipping zone.', 'kiriminaja-official');
                $this->supports = array(
                    'shipping-zones',
                    'instance-settings',
                    'instance-settings-modal',
                );
                
                $this->init();
                $this->enabled = isset($this->settings['enabled']) ? $this->settings['enabled'] : 'yes';
                $this->title = $this->get_option( 'title', __('KiriminAja', 'kiriminaja-official') );
            }
    
            /**
            * Load the settings API
            */
            function init(){
                $this->initFormFields();
                $this->initInstanceFormFields();
                $this->init_settings();
                add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
            }
    
            function initFormFields(){
                $this->form_fields = array(
                        'enabled' => array(
                        'title' => __('Enable', 'kiriminaja-official'),
                        'type' => 'checkbox',
                        'default' => 'yes'
                    ),
                    'title' => array(
                        'title' => __('Title', 'kiriminaja-official'),
                        'type' => 'text',
                        'default' => __('KiriminAja', 'kiriminaja-official')
                    ),
                );
            }

            function initInstanceFormFields(){
                $this->instance_form_fields = array(
                    'title' => array(
                        'title'       => __('Title', 'kiriminaja-official'),
                        'type'        => 'text',
                        'description' => __('This controls the title shown to customers during checkout.', 'kiriminaja-official'),
                        'default'     => __('KiriminAja', 'kiriminaja-official'),
                        'desc_tip'    => true,
                    ),
                );
            }
    
            public function calculate_shipping( $package = array() ){
                if ( ! $this->kiriof_has_sufficient_checkout_address( $package ) ) {
                    if ( function_exists( 'WC' ) && WC() && isset( WC()->session ) && WC()->session ) {
                        WC()->session->set( 'kiriof_shipping_coupon_rate_meta', array() );
                    }
                    if ( function_exists( 'kiriof_log' ) ) {
                        kiriof_log(
                            'info',
                            'KiriminAja shipping rates hidden because checkout address is too short.',
                            array(
                                'address_length' => $this->kiriof_get_checkout_address_length( $package ),
                                'minimum_length' => self::KIRIOF_MIN_ADDRESS_LENGTH,
                            )
                        );
                    }
                    return;
                }

                if ($this->hasActiveFreeShippingCoupon()) {
                    if ( function_exists( 'WC' ) && WC() && isset( WC()->session ) && WC()->session ) {
                        WC()->session->set( 'kiriof_shipping_coupon_rate_meta', array() );
                    }
                    // Add a 0-cost rate so KiriminAja remains a valid shipping option
                    // rather than leaving the customer with no available shipping methods.
                    $this->add_rate( array(
                        'id'    => $this->id . '_free',
                        'label' => __( 'Free shipping', 'kiriminaja-official' ),
                        'cost'  => 0,
                    ) );
                    return;
                }

                $destination_id = WC()->session->get( 'shipping_destination_id' );
                if ( empty( $destination_id ) ) {
                    $destination_id = WC()->session->get( 'destination_id' );
                }
                // Fallback: read from customer additional fields in case the
                // session was not persisted between API requests.
                if ( empty( $destination_id ) ) {
                    try {
                        if ( isset( WC()->customer ) && is_object( WC()->customer ) ) {
                            $meta_keys = array(
                                'shipping_kiriof_destination_area',
                                'shipping_kiriminaja-official/kiriof_destination_area',
                                'kiriminaja-official/kiriof_destination_area',
                                '_wc_blocks_checkout_field_kiriminaja-official/kiriof_destination_area',
                                'additional_field_kiriminaja-official/kiriof_destination_area',
                            );
                            foreach ( $meta_keys as $mk ) {
                                $dest = WC()->customer->get_meta( $mk );
                                if ( ! empty( $dest ) ) {
                                    $destination_id = (int) $dest;
                                    kiriof_log( 'info', 'Fallback: found destination_id=' . $destination_id . ' from meta key: ' . $mk );
                                    break;
                                }
                            }
                            // Dump all customer meta if still not found
                            if ( empty( $destination_id ) ) {
                                $all_meta = WC()->customer->get_meta_data();
                                foreach ( $all_meta as $m ) {
                                    if ( stripos( $m->key, 'kiriof_destination_area' ) !== false ) {
                                        $destination_id = (int) $m->value;
                                        kiriof_log( 'info', 'Fallback: found via scan meta key=' . $m->key . ' value=' . $m->value );
                                        break;
                                    }
                                }
                            }
                        } else {
                            kiriof_log( 'warning', 'Fallback: WC()->customer not available' );
                        }
                    } catch ( \Exception $e ) {
                        kiriof_log( 'error', 'Fallback exception: ' . $e->getMessage() );
                    }
                }

                kiriof_log( 'info', 'calculate_shipping destination_id=' . ( is_scalar( $destination_id ) ? (string) $destination_id : wp_json_encode( $destination_id ) ) );
                $kiriof_insurance = WC()->session->get( 'kiriof_insurance' );

                if ( empty( $destination_id ) ) {
                    if ( function_exists( 'WC' ) && WC() && isset( WC()->session ) && WC()->session ) {
                        WC()->session->set( 'kiriof_shipping_coupon_rate_meta', array() );
                    }
                    return;
                }
                  
                
                $length = 0;
                $width = 0;
                $height = 0;
                $quantity = 0;
                foreach ($package['contents'] as $item_id => $values) {
                    $_product = $values['data'];
                    $quantity += $values['quantity'];
                    $length += (int) $_product->get_length();
                    $width += (int) $_product->get_width();
                    $height += (int) $_product->get_height();
                }

                $settingRepository = new \KiriminAjaOfficial\Repositories\SettingRepository();
                $settingRepo = $settingRepository->getSettingByKey('origin_sub_district_id');
                if(!$settingRepo||$settingRepo->value === null){
                    wc_add_notice(__("Silahkan Input Terlebih dahulu Origin di Plugin Kiriminaja",'kiriminaja-official'), "error");
                    return;
                }
                $courier_filter = $settingRepository->getWhitelistExpeditionIds();

                /** convert unit weight */
                $cartAttributes = (new \KiriminAjaOfficial\Services\UtilServices\GetWCCartAttributeService([
                    'wc_cart_contents' => WC()->cart->get_cart()
                ]))->call();

                $payload = [
                    'subdistrict_origin' => (int) $settingRepo->value,
                    'subdistrict_destination'=>$destination_id,
                    'weight' => $cartAttributes->data['weight'],
                    'length' => $cartAttributes->data['length'],
                    'width' =>  $cartAttributes->data['width'],
                    'height' => $cartAttributes->data['height'],
                    'insurance' => (int) $kiriof_insurance,
                    'item_value' => (int) ($cartAttributes->data['item_value'] ?? 0),
                    'courier' => ! empty( $courier_filter ) ? $courier_filter : "", // 'jne', 'pos', 'tiki', 'jet'
                ];

                $cachedPricingData = \KiriminAjaOfficial\Services\CheckoutServices\PricingCacheService::get( $payload );
                if ( $cachedPricingData ) {
                    $kiriofPricing = array(
                        'status' => true,
                        'data'   => $cachedPricingData,
                    );
                } else {
                    $kiriofPricing = (new \KiriminAjaOfficial\Repositories\KiriminajaApiRepository())->getPricing($payload);
                    if ( ! empty( $kiriofPricing['status'] ) && ! empty( $kiriofPricing['data'] ) ) {
                        \KiriminAjaOfficial\Services\CheckoutServices\PricingCacheService::put( $payload, $kiriofPricing['data'] );
                    }
                }
                kiriof_log( 'info', 'getPricing result keys=' . ( is_array( $kiriofPricing ) ? implode( ',', array_keys( $kiriofPricing ) ) : gettype( $kiriofPricing ) ) );
                if ( isset( $kiriofPricing['status'] ) ) {
                    kiriof_log( 'info', 'getPricing status=' . ( is_scalar( $kiriofPricing['status'] ) ? (string) $kiriofPricing['status'] : wp_json_encode( $kiriofPricing['status'] ) ) );
                }
                if ( isset( $kiriofPricing['data'] ) && is_array( $kiriofPricing['data'] ) ) {
                    kiriof_log( 'info', 'getPricing data count=' . count( $kiriofPricing['data'] ) );
                }
                
                $res_pricing = $kiriofPricing['data']; //object
                $kiriofRateMetaMap = array();
                foreach($this->filterOptions($res_pricing, $quantity, $kiriof_insurance) as $row){
                    
                    $rowMeta    = $row['meta_data'] ?? [];
                    $origCost   = (float) ( $rowMeta['kiriof_shipping_coupon_original_cost'] ?? $row['cost'] );
                    $discAmount = (float) ( $rowMeta['kiriof_shipping_coupon_discount_amount'] ?? 0 );
                    $notice     = (string) ( $rowMeta['kiriof_shipping_coupon_notice'] ?? '' );
                    $badge      = (string) ( $rowMeta['kiriof_shipping_coupon_badge'] ?? '' );

                    // Only pass display-safe meta to the WC_Shipping_Rate object.
                    // Coupon pricing meta (original_cost, discount_amount, notice, badge)
                    // must NOT be included here: WooCommerce Block checkout (e.g. ShopVerse)
                    // reads ALL meta_data from WC_Shipping_Rate and renders each value as a
                    // sub-line in the Order Summary, causing numeric prices to appear janky.
                    // Those values are stored in the WC session (kiriof_shipping_coupon_rate_meta).
                    $rate = array(
                        'id'        => $this->id . '_' . $row['key'],
                        'label'     => $row['value'],
                        'cost'      => $row['cost'],
                        'meta_data' => array(
                            'kiriof_rate_eta'           => (string) ( $rowMeta['kiriof_rate_eta'] ?? '' ),
                            'kiriof_rate_description'   => (string) ( $rowMeta['kiriof_rate_description'] ?? '' ),
                            'kiriof_rate_service'       => (string) ( $rowMeta['kiriof_rate_service'] ?? '' ),
                            'kiriof_rate_service_type'  => (string) ( $rowMeta['kiriof_rate_service_type'] ?? '' ),
                            'kiriof_rate_cod_available' => (string) ( $rowMeta['kiriof_rate_cod_available'] ?? '' ),
                        ),
                    );

                    $kiriofRateMetaMap[ $rate['id'] ] = array(
                        'label'                   => (string) $rate['label'],
                        'cost'                    => (float) $rate['cost'],
                        'original_cost'           => $origCost,
                        'discount_amount'         => $discAmount,
                        'notice'                  => $notice,
                        'badge'                   => $badge,
                        'eta'                     => (string) ( $rowMeta['kiriof_rate_eta'] ?? '' ),
                        'description'             => (string) ( $rowMeta['kiriof_rate_description'] ?? '' ),
                        'service'                 => (string) ( $rowMeta['kiriof_rate_service'] ?? '' ),
                        'service_type'            => (string) ( $rowMeta['kiriof_rate_service_type'] ?? '' ),
                        'cod_available'           => (string) ( $rowMeta['kiriof_rate_cod_available'] ?? '' ),
                        'formatted_cost'          => wp_strip_all_tags( wc_price( (float) $rate['cost'] ) ),
                        'formatted_original_cost' => wp_strip_all_tags( wc_price( $origCost ) ),
                    );

                    $this->add_rate($rate);
                    $this->applyRateDisplayMetadata(
                        $rate['id'],
                        (string) ( $rowMeta['kiriof_rate_description'] ?? '' ),
                        (string) ( $rowMeta['kiriof_rate_eta'] ?? '' )
                    );
                }

                if ( function_exists( 'WC' ) && WC() && isset( WC()->session ) && WC()->session ) {
                    $existingRateMetaMap = (array) WC()->session->get( 'kiriof_shipping_coupon_rate_meta', array() );
                    WC()->session->set( 'kiriof_shipping_coupon_rate_meta', array_merge( $existingRateMetaMap, $kiriofRateMetaMap ) );
                }

                if ( function_exists( 'kiriof_log' ) ) {
                    $discountedRates = array_filter(
                        $kiriofRateMetaMap,
                        static function ( $rateMeta ) {
                            return isset( $rateMeta['discount_amount'] ) && (float) $rateMeta['discount_amount'] > 0;
                        }
                    );

                    kiriof_log(
                        'info',
                        'Shipping discount rate metadata refreshed.',
                        array(
                            'rate_count' => count( $kiriofRateMetaMap ),
                            'discounted_rate_count' => count( $discountedRates ),
                            'discounted_rate_ids' => array_keys( $discountedRates ),
                            'applied_coupons' => function_exists( 'WC' ) && WC() && isset( WC()->cart ) && WC()->cart && method_exists( WC()->cart, 'get_applied_coupons' )
                                ? array_values( array_map( 'strval', (array) WC()->cart->get_applied_coupons() ) )
                                : array(),
                        ),
                        'shipping_discount_coupon'
                    );
                }

            }

            private function kiriof_has_sufficient_checkout_address( $package ): bool {
                return $this->kiriof_get_checkout_address_length( $package ) >= self::KIRIOF_MIN_ADDRESS_LENGTH;
            }

            private function kiriof_get_checkout_address_length( $package ): int {
                $address = $this->kiriof_get_checkout_address( $package );

                if ( function_exists( 'mb_strlen' ) ) {
                    return mb_strlen( $address );
                }

                return strlen( $address );
            }

            private function kiriof_get_checkout_address( $package ): string {
                $package_address = $this->kiriof_get_package_destination_address( $package );
                if ( '' !== $package_address ) {
                    return $package_address;
                }

                if ( ! function_exists( 'WC' ) || ! WC() || ! isset( WC()->customer ) || ! WC()->customer ) {
                    return '';
                }

                foreach ( array( 'get_shipping_address', 'get_billing_address' ) as $method ) {
                    if ( method_exists( WC()->customer, $method ) ) {
                        $address = trim( (string) WC()->customer->{$method}() );
                        if ( '' !== $address ) {
                            return $address;
                        }
                    }
                }

                return '';
            }

            private function kiriof_get_package_destination_address( $package ): string {
                if ( ! is_array( $package ) || empty( $package['destination'] ) || ! is_array( $package['destination'] ) ) {
                    return '';
                }

                foreach ( array( 'address_1', 'address' ) as $key ) {
                    if ( array_key_exists( $key, $package['destination'] ) ) {
                        $address = trim( (string) $package['destination'][ $key ] );
                        if ( '' !== $address ) {
                            return $address;
                        }
                    }
                }

                return '';
            }

            private function applyRateDisplayMetadata($rate_id, $description, $delivery_time) {
                if ( ! isset( $this->rates[ $rate_id ] ) || ! $this->rates[ $rate_id ] instanceof \WC_Shipping_Rate ) {
                    return;
                }

                if ( '' !== $description && method_exists( $this->rates[ $rate_id ], 'set_description' ) ) {
                    $this->rates[ $rate_id ]->set_description( $description );
                }

                if ( '' !== $delivery_time && method_exists( $this->rates[ $rate_id ], 'set_delivery_time' ) ) {
                    $this->rates[ $rate_id ]->set_delivery_time( $delivery_time );
                }
            }

            public function filterOptions($pricingData, $quantity, $kiriof_insurance = null){

                $shippingDiscountService = new \KiriminAjaOfficial\Services\ShippingDiscountCouponService();

                $chosen_payment_method = WC()->session->get('chosen_payment_method') ?: WC()->session->get('kiriof_payment_method');

                /**
                 * Payment is only needed to decide whether we should restrict
                 * rates to COD-capable services. Classic checkout can calculate
                 * shipping during update_order_review before a payment radio is
                 * checked, so an empty payment method must still show regular
                 * non-COD shipping rates instead of hiding the whole list.
                 */
                $is_cod = $chosen_payment_method === 'cod';

                $options = $pricingData->results ?? [];

                
                $validate = (new \KiriminAjaOfficial\Repositories\SettingRepository())->validateWhiteListExpedition($options);
                
                
                $options = $validate;
                
                $filteredOptions = [];
                $allOptions = [];
                foreach ($options as $option){
                    $shipping_cost = $option->cost - $option->discount_amount;
                    $shippingDiscountPricing = $shippingDiscountService->getAdjustedRatePricing($option, (float) $shipping_cost);

                    $rateOption = [
                        'key'=>$option->service.'_'.$option->service_type,
                        'value'=>kiriof_helper()->formatServiceName($option->service, $option->service_name),
                        'cost'=>$shippingDiscountPricing['cost'],
                        'meta_data'=>[
                            'kiriof_shipping_coupon_original_cost' => (float) $shippingDiscountPricing['original_cost'],
                            'kiriof_shipping_coupon_discount_amount' => (float) $shippingDiscountPricing['discount_amount'],
                            'kiriof_shipping_coupon_notice' => (string) $shippingDiscountPricing['notice'],
                            'kiriof_shipping_coupon_badge' => (string) $shippingDiscountPricing['badge'],
                            'kiriof_rate_eta' => $this->formatEta($option),
                            'kiriof_rate_description' => $this->formatRateDescription($option, $kiriof_insurance),
                            'kiriof_rate_service' => isset( $option->service ) ? (string) $option->service : '',
                            'kiriof_rate_service_type' => isset( $option->service_type ) ? (string) $option->service_type : '',
                            'kiriof_rate_cod_available' => $this->isCodCapableOption($option) ? 'yes' : 'no',
                        ],
                    ];

                    $allOptions[] = $rateOption;

                    if (!$is_cod || $this->isCodCapableOption($option)){
                        $filteredOptions[] = $rateOption;
                    }
                }

                // Sort by cost ascending, then by name for stable ordering
                usort($filteredOptions, function($a, $b) {
                    $costCmp = $a['cost'] <=> $b['cost'];
                    if ( 0 !== $costCmp ) {
                        return $costCmp;
                    }
                    return strcasecmp($a['value'], $b['value']);
                });
                
                return $filteredOptions;
            }

            private function isCodCapableOption($option) {
                $codValue = $option->cod ?? null;
                if ($this->isTruthyCodValue($codValue)) {
                    return true;
                }

                $setting = is_object($option) && isset($option->setting) && is_object($option->setting)
                    ? $option->setting
                    : null;
                if (!$setting) {
                    return false;
                }

                foreach (array('cod', 'is_cod', 'cod_enabled', 'cod_available') as $key) {
                    if (isset($setting->{$key}) && $this->isTruthyCodValue($setting->{$key})) {
                        return true;
                    }
                }

                foreach (array('cod_fee_amount', 'minimum_cod_fee', 'cod_fee') as $key) {
                    if (isset($setting->{$key}) && (float) $setting->{$key} > 0) {
                        return true;
                    }
                }

                return false;
            }

            private function isTruthyCodValue($value) {
                if (is_bool($value)) {
                    return $value;
                }
                if (is_numeric($value)) {
                    return (float) $value > 0;
                }
                if (is_string($value)) {
                    return in_array(strtolower(trim($value)), array('1', 'true', 'yes', 'y', 'available', 'enabled'), true);
                }

                return false;
            }

            private function formatEta($option) {
                $eta = '';

                foreach ( array( 'etd', 'eta', 'estimation', 'estimation_day', 'lead_time' ) as $field ) {
                    if ( isset( $option->{$field} ) && '' !== (string) $option->{$field} ) {
                        $eta = (string) $option->{$field};
                        break;
                    }
                }

                $eta = trim( preg_replace( '/\s+/', ' ', $eta ) );
                if ( '' === $eta ) {
                    return '';
                }

                if ( preg_match( '/business day/i', $eta ) ) {
                    return $eta;
                }

                if ( preg_match( '/^\d+\s*(?:-|to)\s*\d+$/i', $eta ) ) {
                    return $eta . ' business days';
                }

                if ( preg_match( '/^\d+$/', $eta ) ) {
                    return '1' === $eta ? '1 business day' : $eta . ' business days';
                }

                return $eta;
            }

            private function formatRateDescription($option, $kiriof_insurance) {
                $parts = array();
                $service_type = isset( $option->service_type ) ? strtoupper( trim( (string) $option->service_type ) ) : '';
                $service_label = $this->describeServiceType( $service_type );

                if ( '' !== $service_label ) {
                    $parts[] = $service_label;
                }

                if ( ! empty( $kiriof_insurance ) ) {
                    $parts[] = __( 'Includes insurance', 'kiriminaja-official' );
                }

                return implode( ' • ', array_filter( $parts ) );
            }

            private function describeServiceType( $service_type ) {
                $service_type = strtoupper( preg_replace( '/[^A-Z]/', '', (string) $service_type ) );

                if ( '' === $service_type ) {
                    return '';
                }

                $map = array(
                    'JTR' => __( 'Cargo service', 'kiriminaja-official' ),
                    'REG' => __( 'Regular service', 'kiriminaja-official' ),
                    'OKE' => __( 'Economy service', 'kiriminaja-official' ),
                    'YES' => __( 'Next-day service', 'kiriminaja-official' ),
                    'SDS' => __( 'Same-day service', 'kiriminaja-official' ),
                    'ONS' => __( 'Overnight service', 'kiriminaja-official' ),
                );

                foreach ( $map as $prefix => $label ) {
                    if ( 0 === strpos( $service_type, $prefix ) ) {
                        return $label;
                    }
                }

                return ucwords( strtolower( $service_type ) ) . ' ' . __( 'service', 'kiriminaja-official' );
            }

            private function hasActiveFreeShippingCoupon(){
                if (!function_exists('WC') || !WC() || !isset(WC()->cart) || !WC()->cart) {
                    return false;
                }

                foreach (WC()->cart->get_coupons() as $coupon) {
                    if ($coupon && method_exists($coupon, 'get_free_shipping') && $coupon->get_free_shipping()) {
                        return true;
                    }
                }

                return false;
            }
            
        }
    }
}


add_filter('woocommerce_shipping_methods', 'kiriof_add_shipping_method');
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Required for WooCommerce filter callback
function kiriof_add_shipping_method($methods){
    $methods['kiriminaja-official'] = 'Kiriof_Shipping_Method_Controller';
    return $methods;
}

add_filter( 'woocommerce_add_to_cart_validation', 'kiriof_add_date_validation', 10, 5 );
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Required for WooCommerce filter callback
function kiriof_add_date_validation( $passed, $product_id, $quantity = 1, $variation_id = 0 ) { 
    
    $product = wc_get_product( $variation_id ?: $product_id );
    if ( ! $product ) {
        return $passed;
    }

    if ( method_exists( $product, 'needs_shipping' ) && ! $product->needs_shipping() ) {
        return $passed;
    }

    $length = $product->get_length();
    $width = $product->get_width();
    $height = $product->get_height();
    
    $settingRepo = (new \KiriminAjaOfficial\Repositories\SettingRepository())->getSettingByKey('origin_sub_district_id');
    if(!$settingRepo||$settingRepo->value === null){
        wc_add_notice(__("Silahkan Input Terlebih dahulu Origin di Plugin Kiriminaja",'kiriminaja-official'), "error");
        $passed = false;
    }
    /**
     * Check Product Weight
     */
    if( empty($product->get_weight()) ){
        wc_add_notice(__("Maaf Produk ini Tidak Memiliki Berat untuk Pengiriman",'kiriminaja-official'), "error");
        $passed = false;
    }

    /**
     * Check Product Dimention
     */
    if ( empty($length) || empty($width) || empty($height)) {
        wc_add_notice(__('Maaf Produk ini Tidak Memiliki Dimension untuk Pengiriman', 'kiriminaja-official'), 'error');
        $passed = false;
    }

    return $passed;

}

add_filter( 'woocommerce_shipping_calculator_enable_country', '__return_false' );
add_filter( 'woocommerce_shipping_calculator_enable_city', '__return_false' );
add_filter( 'woocommerce_shipping_calculator_enable_state', '__return_false' );
add_filter( 'woocommerce_shipping_calculator_enable_postcode', '__return_false' );
