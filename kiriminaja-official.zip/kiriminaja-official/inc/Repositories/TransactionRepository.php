<?php
namespace KiriminAjaOfficial\Repositories;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- All queries use wpdb::prepare() correctly, table names must be interpolated
class TransactionRepository{
    public $table;
    private $wpdb;
    
    public function __construct(){
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table = $wpdb->prefix . 'kiriminaja_transactions';
    }
    
    /**
     * Whether WooCommerce HPOS (custom orders table) is the active storage.
     */
    private function isHPOS() {
        return class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class )
            && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
    }

    /**
     * Return the orders table name and column aliases depending on storage.
     * HPOS  → {prefix}wc_orders  (id, date_created_gmt, status)
     * Legacy → {prefix}posts      (ID, post_date, post_status, post_type)
     */
    public function getOrdersTable() {
        $prefix = $this->wpdb->prefix;
        if ( $this->isHPOS() ) {
            return [
                'table'       => "{$prefix}wc_orders",
                'id'          => 'id',
                'date'        => 'date_created_gmt',
                'status'      => 'status',
                'type_col'    => 'type',
                'type_value'  => 'shop_order',
                'trash_field' => 'status',
            ];
        }
        return [
            'table'       => "{$prefix}posts",
            'id'          => 'ID',
            'date'        => 'post_date',
            'status'      => 'post_status',
            'type_col'    => 'post_type',
            'type_value'  => 'shop_order',
            'trash_field' => 'post_status',
        ];
    }

    public function getShippableOrderExistsSql( string $orderIdExpression ): string {
        $order_items_table     = $this->wpdb->prefix . 'woocommerce_order_items';
        $order_itemmeta_table  = $this->wpdb->prefix . 'woocommerce_order_itemmeta';
        $postmeta_table        = $this->wpdb->postmeta;

        return "AND EXISTS (
            SELECT 1
            FROM {$order_items_table} oi
            LEFT JOIN {$order_itemmeta_table} oim_var
                ON oim_var.order_item_id = oi.order_item_id
                AND oim_var.meta_key = '_variation_id'
            LEFT JOIN {$postmeta_table} pm_var
                ON pm_var.post_id = oim_var.meta_value
                AND pm_var.meta_key = '_virtual'
            LEFT JOIN {$order_itemmeta_table} oim_prod
                ON oim_prod.order_item_id = oi.order_item_id
                AND oim_prod.meta_key = '_product_id'
            LEFT JOIN {$postmeta_table} pm_prod
                ON pm_prod.post_id = oim_prod.meta_value
                AND pm_prod.meta_key = '_virtual'
            WHERE oi.order_id = {$orderIdExpression}
                AND oi.order_item_type = 'line_item'
                AND COALESCE(NULLIF(pm_var.meta_value, ''), pm_prod.meta_value, 'no') <> 'yes'
        )";
    }

    /**
     * Check for database errors and log them
     * @return bool
     */
    private function hasError(){
        if (!empty($this->wpdb->last_error)) {
            (new \KiriminAjaOfficial\Base\BaseInit())->logThis($this->wpdb->last_error);
            return true;
        }
        return false;
    }
    
    public function getTransactionByOrderIds($orderIds){
        if (empty($orderIds)) {
            return [];
        }
        
        $count = count($orderIds);
        $placeholders = implode(',', array_fill(0, $count, '%s'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        $query = $this->wpdb->get_results(
            $this->wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT * FROM {$this->table} WHERE order_id IN ({$placeholders})",
                ...$orderIds
            )
        );
        return $this->hasError() ? false : $query;
    }
    
    public function getTransactionByOrderId($orderId){
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        $query = $this->wpdb->get_row( 
            $this->wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT * FROM {$this->table} WHERE `order_id` = %s",
                $orderId
            )
        );
        
        return $this->hasError() ? false : $query;
    }
    
    public function getTransactionByWCOrderNumber($wp_wc_order_stat_order_id){
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        $query = $this->wpdb->get_row(
            $this->wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT * FROM {$this->table} WHERE `wp_wc_order_stat_order_id` = %d",
                $wp_wc_order_stat_order_id
            )
        );
        
        return $this->hasError() ? false : $query;
    }
    
    public function getTransactionByWCOrderNumberForTracking($wp_wc_order_stat_order_id){
        $wp_wc_order_stat_order_id = absint( $wp_wc_order_stat_order_id );
        if ( 0 === $wp_wc_order_stat_order_id ) {
            return false;
        }

        $transactions_table = esc_sql( $this->table );
        $wc_stats_table     = esc_sql( $this->wpdb->prefix . 'wc_order_stats' );
        $posts_table        = esc_sql( $this->wpdb->posts );
        
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $query = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT 
                    t.*, 
                    w.date_paid as wc_date_paid,
                    p.post_status as wc_post_status
                FROM {$transactions_table} t
                INNER JOIN {$wc_stats_table} w ON t.wp_wc_order_stat_order_id = w.order_id
                INNER JOIN {$posts_table} p ON w.order_id = p.ID
                WHERE t.wp_wc_order_stat_order_id = %d AND p.post_status != %s
                GROUP BY t.wp_wc_order_stat_order_id",
                $wp_wc_order_stat_order_id,
                'trash'
            )
        );
        
        return $this->hasError() ? false : $query;
    }
    public function getTransactionByAWBforTracking($trackingNumber){
        $trackingNumber = trim( (string) $trackingNumber );
        if ( '' === $trackingNumber ) {
            return false;
        }

        $normalizedTrackingNumber = preg_replace( '/[^A-Za-z0-9]/', '', $trackingNumber );
        if ( '' === $normalizedTrackingNumber ) {
            $normalizedTrackingNumber = $trackingNumber;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        $get_wc_orderid = $this->wpdb->get_row( 
            $this->wpdb->prepare(
                //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT wp_wc_order_stat_order_id FROM {$this->table} WHERE `awb` = %s OR REPLACE(REPLACE(`awb`, '-', ''), ' ', '') = %s OR `order_id` = %s OR REPLACE(REPLACE(`order_id`, '-', ''), ' ', '') = %s OR `wp_wc_order_stat_order_id` = %d",
                $trackingNumber,
                $normalizedTrackingNumber,
                $trackingNumber,
                $normalizedTrackingNumber,
                absint( $trackingNumber )
            )
        );
        if ($this->hasError() || !$get_wc_orderid) {
            return false;
        }
        return $this->getTransactionByWCOrderNumberForTracking($get_wc_orderid->wp_wc_order_stat_order_id);
    }
    
    public function getTransactionByPickupNumber($pickupNumber){
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        $query = $this->wpdb->get_results( 
            $this->wpdb->prepare(
                //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT * FROM {$this->table} WHERE pickup_number = %s",
                $pickupNumber
            )
        );
        
        return $this->hasError() ? false : $query;
    }
    
    public function updateTransactionByCallback($payloads){
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $this->wpdb->update($this->table, $payloads['changes'], $payloads['condition']);
        
        return !$this->hasError();
    }

    /**
     * Update a transaction and verify idempotent zero-row writes.
     *
     * @param array $payloads Update changes and conditions.
     * @return bool
     */
    public function updateTransactionByCallbackVerified( $payloads ) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $updated = $this->wpdb->update( $this->table, $payloads['changes'], $payloads['condition'] );

        if ( false === $updated || $this->hasError() ) {
            return false;
        }

        if ( $updated > 0 ) {
            return true;
        }

        $order_id = $payloads['condition']['order_id'] ?? '';
        if ( '' === (string) $order_id ) {
            return false;
        }

        $transaction = $this->getTransactionByOrderId( $order_id );
        if ( ! $transaction ) {
            return false;
        }

        foreach ( $payloads['changes'] as $field => $value ) {
            if ( ! property_exists( $transaction, $field ) || (string) $transaction->{$field} !== (string) $value ) {
                return false;
            }
        }

        return true;
    }
    
    /**
     * Alias for getTransactionByPickupNumber
     * @deprecated Use getTransactionByPickupNumber instead
     */
    public function getTransactionDataByPickupNumber($pickupNumber){
        return $this->getTransactionByPickupNumber($pickupNumber);
    }
    public function getTransactionByWCOrderId($WCOrderId){
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        $query = $this->wpdb->get_row( 
            $this->wpdb->prepare(
                //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT * FROM {$this->table} WHERE wp_wc_order_stat_order_id = %d",
                $WCOrderId
            )
        );
        
        return $this->hasError() ? false : $query;
    }
    
    public function createTransaction($payload){
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        $this->wpdb->query(
            $this->wpdb->prepare(
                //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "INSERT INTO {$this->table} 
                (
                    `order_id`, 
                    `shipping_info`, 
                    `destination_sub_district_id`, 
                    `destination_sub_district`, 
                    `status`, 
                    `service`, 
                    `service_name`, 
                    `weight`, 
                    `width`, 
                    `height`, 
                    `length`, 
                    `shipping_cost`, 
                    `insurance_cost`, 
                    `cod_fee`, 
                    `transaction_value`, 
                    `created_at`, 
                    `wp_wc_order_stat_order_id`,
                    `discount_amount`,
                    `discount_percentage`,
                    `woocommerce_discount_amount`,
                    `woocommerce_discount_description`,
                    `is_deficit`,
                    `cod_minimum`
                ) 
                VALUES (%s, %s, %d, %s, %s, %s, %s, %d, %f, %f, %f, %f, %f, %f, %f, %s, %d, %f, %f, %f, %s, %d, %f)",
                $payload['order_id'],
                $payload['shipping_info'],
                $payload['destination_sub_district_id'],
                $payload['destination_sub_district'],
                $payload['status'],
                $payload['service'],
                $payload['service_name'],
                $payload['weight'],
                $payload['width'],
                $payload['height'],
                $payload['length'],
                $payload['shipping_cost'],
                $payload['insurance_cost'],
                $payload['cod_fee'],
                $payload['transaction_value'],
                $payload['created_at'],
                $payload['wp_wc_order_stat_order_id'],
                $payload['discount_amount'] ?? null,
                $payload['discount_percentage'] ?? null,
                $payload['woocommerce_discount_amount'] ?? 0,
                $payload['woocommerce_discount_description'] ?? null,
                $payload['is_deficit'] ?? 0,
                $payload['cod_minimum'] ?? null
            )
        );
        $this->invalidateCouriersCache();
        return !$this->hasError();
    }
    public function getTransactionByOldestDate(){
        $shippable_order_clause = $this->getShippableOrderExistsSql( 'wp_wc_order_stat_order_id' );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $shippable_order_clause is built from controlled internal SQL fragments only.
        $query = $this->wpdb->get_row(
            "SELECT * FROM {$this->table} WHERE created_at IS NOT NULL {$shippable_order_clause} ORDER BY created_at ASC LIMIT 1"
        );
        
        return $this->hasError() ? false : $query;
    }
    public function getTransactionByOrderIdsForResiPrint($orderIds){
        if (empty($orderIds)) {
            return [];
        }
        
        $prefix = $this->wpdb->prefix;
        $count = count($orderIds);
        $placeholders = implode(', ', array_fill(0, $count, '%d'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        $query = $this->wpdb->get_results( 
            $this->wpdb->prepare(
                //phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT 
                    t.*,
                    p.post_excerpt as checkout_note,
                    COUNT(w.product_id) as item_count
                FROM {$this->table} t
                INNER JOIN {$prefix}posts p ON t.wp_wc_order_stat_order_id = p.ID
                INNER JOIN {$prefix}wc_order_product_lookup w ON t.wp_wc_order_stat_order_id = w.order_id
                WHERE t.order_id IN ({$placeholders})
                GROUP BY t.wp_wc_order_stat_order_id",
                ...$orderIds
            )
         );
         
        return $this->hasError() ? false : $query;
    }
    /**
     * @deprecated Typo in method name, use getTransactionByOrderIds instead
     */
    public function getTransctionByOrderIds($orderIds){
        return $this->getTransactionByOrderIds($orderIds);
    }
    public function getCountTransactionProcessNew(){
        return $this->getCountByPostStatus( 'wc-processing' );
    }

    /**
     * Distinct order count for the Transactions list.
     * Pass null/empty/'all' to count every status — used by the "All"
     * pill on the Transactions page so the badge matches the rendered rows.
     */
    public function getCountByPostStatus( $postStatus ){
        $o = $this->getOrdersTable();
        $shippable_order_clause = $this->getShippableOrderExistsSql( "p.{$o['id']}" );

        if ( null === $postStatus || '' === $postStatus || 'all' === $postStatus ) {
            // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $query = $this->wpdb->get_var(
                $this->wpdb->prepare(
                    "SELECT COUNT(DISTINCT p.{$o['id']})
                    FROM {$o['table']} p
                    INNER JOIN {$this->table} t
                        ON p.{$o['id']} = t.wp_wc_order_stat_order_id
                    WHERE p.{$o['type_col']} = %s
                        AND p.{$o['trash_field']} NOT IN ('trash','auto-draft')
                        {$shippable_order_clause}",
                    $o['type_value']
                )
            );
            // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        } else {
            // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $query = $this->wpdb->get_var(
                $this->wpdb->prepare(
                    "SELECT COUNT(DISTINCT p.{$o['id']})
                    FROM {$o['table']} p
                    INNER JOIN {$this->table} t
                        ON p.{$o['id']} = t.wp_wc_order_stat_order_id
                    WHERE p.{$o['status']} = %s
                        AND t.status = %s
                        {$shippable_order_clause}",
                    $postStatus,
                    'new'
                )
            );
            // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        }

        return $this->hasError() ? 0 : (int) $query;
    }

    /**
     * Count distinct orders that have already been processed — i.e. have
     * a matching record in kiriminaja_payments (synced with the Payments
     * / Request Pickup page). Excludes cancelled transactions.
     */
    public function getCountProcessed() {
        $o = $this->getOrdersTable();
        $shippable_order_clause = $this->getShippableOrderExistsSql( "p.{$o['id']}" );

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $query = $this->wpdb->get_var(
            "SELECT COUNT(DISTINCT p.{$o['id']})
            FROM {$o['table']} p
            INNER JOIN {$this->table} t
                ON p.{$o['id']} = t.wp_wc_order_stat_order_id
            INNER JOIN {$this->wpdb->prefix}kiriminaja_payments pay
                ON t.pickup_number = pay.pickup_number
            WHERE p.{$o['trash_field']} NOT IN ('trash','auto-draft')
                AND t.status != 'canceled'
                {$shippable_order_clause}"
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

        return $this->hasError() ? 0 : (int) $query;
    }

    /**
     * Count distinct orders that are cancelled in WooCommerce and have
     * a KiriminAja transaction record.
     */
    public function getCountCancelled() {
        $o = $this->getOrdersTable();
        $shippable_order_clause = $this->getShippableOrderExistsSql( "p.{$o['id']}" );

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $query = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(DISTINCT p.{$o['id']})
                FROM {$o['table']} p
                INNER JOIN {$this->table} t
                    ON p.{$o['id']} = t.wp_wc_order_stat_order_id
                WHERE p.{$o['status']} = %s
                    {$shippable_order_clause}",
                'wc-cancelled'
            )
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

        return $this->hasError() ? 0 : (int) $query;
    }

    /**
     * Count distinct orders flagged as COD deficit (is_deficit = 1).
     */
    public function getCountDeficit(): int {
        $o = $this->getOrdersTable();
        $shippable_order_clause = $this->getShippableOrderExistsSql( "p.{$o['id']}" );

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $query = $this->wpdb->get_var(
            "SELECT COUNT(DISTINCT p.{$o['id']})
            FROM {$o['table']} p
            INNER JOIN {$this->table} t
                ON p.{$o['id']} = t.wp_wc_order_stat_order_id
            WHERE p.{$o['trash_field']} NOT IN ('trash','auto-draft')
                AND t.is_deficit = 1
                {$shippable_order_clause}"
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

        return $this->hasError() ? 0 : (int) $query;
    }

    public function getDistinctCouriers() {
        $cache_key = 'kiriof_distinct_couriers';
        $cached    = get_transient($cache_key);
        if (false !== $cached) {
            return $cached;
        }

        $shippable_order_clause = $this->getShippableOrderExistsSql( 't.wp_wc_order_stat_order_id' );

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $shippable_order_clause is built from controlled internal SQL fragments only.
        $results = $this->wpdb->get_results(
            "SELECT DISTINCT service FROM {$this->table} t WHERE service IS NOT NULL AND service != '' {$shippable_order_clause} ORDER BY service ASC"
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter

        if ($this->hasError()) {
            return [];
        }

        set_transient($cache_key, $results, HOUR_IN_SECONDS);
        return $results;
    }

    public function invalidateCouriersCache() {
        delete_transient('kiriof_distinct_couriers');
    }

    /**
     * Update COD-related values for a transaction (used by COD adjustment flow).
     *
     * @param string $kaOrderId  KiriminAja order ID (order_id column).
     * @param array  $values {
     *   @type float $cod              New total COD amount.
     *   @type float $cod_fee          New COD fee.
     *   @type float $cod_minimum      New COD minimum.
     *   @type int   $is_deficit       0 or 1.
     * }
     * @return bool
     */
    public function updateTransactionCodValues( string $kaOrderId, array $values ): bool {
        $allowed = [ 'transaction_value', 'cod_fee', 'cod_minimum', 'is_deficit' ];
        $updateData = array_intersect_key( $values, array_flip( $allowed ) );

        if ( empty( $updateData ) ) {
            return false;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $this->wpdb->update(
            $this->table,
            $updateData,
            [ 'order_id' => $kaOrderId ]
        );

        return ! $this->hasError();
    }

    public function updateTransaction($payload){
        $updateData = [
            'destination_sub_district_id' => $payload['destination_sub_district_id'],
            'destination_sub_district' => $payload['destination_sub_district'],
            'service' => $payload['service'],
            'service_name' => $payload['service_name'],
            'shipping_cost' => $payload['shipping_cost'],
            'insurance_cost' => $payload['insurance_cost'],
            'cod_fee' => $payload['cod_fee'],
        ];
        
        // Add discount fields if provided
        if (isset($payload['discount_amount'])) {
            $updateData['discount_amount'] = $payload['discount_amount'];
        }
        if (isset($payload['discount_percentage'])) {
            $updateData['discount_percentage'] = $payload['discount_percentage'];
        }
        if (isset($payload['woocommerce_discount_amount'])) {
            $updateData['woocommerce_discount_amount'] = $payload['woocommerce_discount_amount'];
        }
        if (isset($payload['woocommerce_discount_description'])) {
            $updateData['woocommerce_discount_description'] = $payload['woocommerce_discount_description'];
        }
        if (isset($payload['is_deficit'])) {
            $updateData['is_deficit'] = $payload['is_deficit'];
        }
        if (isset($payload['cod_minimum'])) {
            $updateData['cod_minimum'] = $payload['cod_minimum'];
        }
        
        $where = ['wp_wc_order_stat_order_id' => $payload['wp_wc_order_stat_order_id']];
        
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $this->wpdb->update($this->table, $updateData, $where);
        $this->invalidateCouriersCache();
        return !$this->hasError();
    }
}
