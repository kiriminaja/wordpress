<?php
namespace KiriminAjaOfficial\Services\TransactionProcessServices;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use KiriminAjaOfficial\Base\BaseService;
class GetRequestPickupScheduleService extends BaseService {
    
    public array $orderIds = [];
    
    public function orderIds($orderIds){
        $this->orderIds = $orderIds;
        return $this;
    }
    
    public function call(){
        $scheduleRepo = (new \KiriminAjaOfficial\Repositories\KiriminajaApiRepository())->getRequestPickupSchedule();
        if (!@$scheduleRepo['status'] || !@$scheduleRepo['data']->status){
            return self::error([],@$scheduleRepo['data']->text ?? 'Something is wrong');
        }
        
        $transactionSummaryData = self::transactionSummaryData();
        
        return self::success([
            'schedules'                 => self::scheduleOptionFormatter(@$scheduleRepo['data']->schedules ?? []),
            'transaction_summary'       => $transactionSummaryData
        ],'success');
    }
    
    private function transactionSummaryData(){
        $transactions = (new \KiriminAjaOfficial\Repositories\TransactionRepository())->getTransactionByOrderIds($this->orderIds);
                
        $count_cod = 0;
        $count_non_cod = 0;
        $sum_fee_cod = 0;
        $sum_fee_non_cod = 0;
        foreach ($transactions as $transaction){
            if ($this->isCodTransaction($transaction)){
                $count_cod+=1;
            }else{
                $count_non_cod+=1;
                $sum_fee_non_cod+=($transaction->shipping_cost - $transaction->discount_amount) + $transaction->insurance_cost;
            }
        }
        $array = [];
        $array['count_cod']         =   $count_cod;
        $array['count_non_cod']     =   $count_non_cod;
        $array['sum_fee_cod']       =   $sum_fee_cod;
        $array['sum_fee_non_cod']   =   $sum_fee_non_cod;
        return $array;
    }

    private function isCodTransaction($transaction){
        if ((float) ($transaction->cod_fee ?? 0) > 0) {
            return true;
        }

        if (empty($transaction->wp_wc_order_stat_order_id) || !function_exists('wc_get_order')) {
            return false;
        }

        $order = wc_get_order((int) $transaction->wp_wc_order_stat_order_id);
        if (!$order) {
            return false;
        }

        return 'cod' === strtolower((string) $order->get_payment_method());
    }
    
    private function scheduleOptionFormatter($schedules){
        return array_map(function ($schedule){
            $schedule->label = gmdate('l, Y-m-d H:i',strtotime($schedule->clock)) . ' WIB';
            return $schedule;
        },$schedules);
    }
}