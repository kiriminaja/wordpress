<?php
namespace KiriminAjaOfficial\Migration;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SetupMigration {
    
    public $suffix = '';
    
    public function register(){
        self::settingsTable();
        self::transactionsTable();
        self::paymentsTable();
        self::regionCacheTables();
    }
    
    private function settingsTable(){
        global $wpdb;
        /** Settings Table*/
        $suffix     = preg_replace( '/[^a-zA-Z0-9_]/', '', (string) $this->suffix );
        $table_name = esc_sql( $wpdb->prefix . 'kiriminaja_settings' . $suffix );
        
        /** Only create table if not exist */
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) !== $table_name ) {
            //phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
            $sql = "CREATE TABLE `" . $table_name . "`(
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            `key` varchar(255) NULL,
            `value` varchar(255) NULL,
            UNIQUE KEY id (id)
            );";
            require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
            dbDelta($sql);
            /** Settings Table Value*/
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching	
            $wpdb->query(
                $wpdb->prepare(
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                    "INSERT INTO `$table_name` (`key`, `value`) VALUES
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s),
                    (%s, %s)",
                    'api_key', null,
                    'setup_key', null,
                    'oid_prefix', null,
                    'origin_name', null,
                    'origin_phone', null,
                    'origin_address', null,
                    'origin_sub_district_id', null,
                    'origin_sub_district_name', null,
                    'origin_latitude', null,
                    'origin_longitude', null,
                    'callback_url', null,
                    'origin_zip_code', null,
                    'enable_cod', 'yes',
                    'enable_insurance', 'yes'
                )
            );
        }
        
        /** Alters*/
        // Ensure is_top row exists for existing installs (added after initial release).
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rowExists = $wpdb->get_var( $wpdb->prepare(
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            "SELECT COUNT(*) FROM `$table_name` WHERE `key` = %s",
            'is_top'
        ) );
        if ( ! $rowExists ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $wpdb->insert( $table_name, array( 'key' => 'is_top', 'value' => 'no' ), array( '%s', '%s' ) );
        }
    }
    
    /**
     * Updates 
     * [+] add Coloumn canceled_at
     * [+] add value cancaled in status
     */
    private function transactionsTable(){
        global $wpdb;
        /** Transactions Table*/
        $suffix     = preg_replace( '/[^a-zA-Z0-9_]/', '', (string) $this->suffix );
        $table_name = esc_sql( $wpdb->prefix . 'kiriminaja_transactions' . $suffix );
        /** Only create table if not exist */
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) !== $table_name ) {
            
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
            $sql = "CREATE TABLE `" . $table_name . "`(
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                `order_id` varchar(100) DEFAULT NULL,
                `shipping_info` text DEFAULT NULL,
                `destination_sub_district_id` int(11) DEFAULT NULL,
                `destination_sub_district` varchar(255) DEFAULT NULL,
                `pickup_number` varchar(100) DEFAULT NULL,
                `status` enum('new','request_pickup','pending','finished','shipped','return','returned','rejected','canceled') NOT NULL DEFAULT 'new',
                `service` varchar(50) DEFAULT NULL,
                `service_name` varchar(50) DEFAULT NULL,
                `awb` varchar(100) DEFAULT NULL,
                `rejected_reason` varchar(255) DEFAULT NULL,
                `weight` int(11) DEFAULT NULL,
                `width` double NOT NULL DEFAULT 0,
                `height` double NOT NULL DEFAULT 0,
                `length` double NOT NULL DEFAULT 0,
                `shipping_cost` double DEFAULT NULL,
                `insurance_cost` double DEFAULT NULL,
                `cod_fee` double DEFAULT NULL,
                `transaction_value` double DEFAULT NULL,
                `discount_amount` double DEFAULT NULL,
                `discount_percentage` double DEFAULT NULL,
                `woocommerce_discount_amount` decimal(15,2) NOT NULL DEFAULT 0,
                `woocommerce_discount_description` varchar(255) DEFAULT NULL,
                `is_deficit` tinyint(1) NOT NULL DEFAULT 0,
                `is_printed` tinyint(1) NOT NULL DEFAULT 0,
                `printed_at` timestamp NULL DEFAULT NULL,
                `cod_minimum` decimal(15,2) DEFAULT NULL,
                `created_at` timestamp NULL DEFAULT NULL,
                `request_pickup_at` timestamp NULL DEFAULT NULL,
                `shipped_at` timestamp NULL DEFAULT NULL,
                `return_finished_at` timestamp NULL DEFAULT NULL,
                `finished_at` timestamp NULL DEFAULT NULL,
                `rejected_at` timestamp NULL DEFAULT NULL,
                `returned_at` timestamp NULL DEFAULT NULL,
                `canceled_at` timestamp NULL DEFAULT NULL,
                `wp_wc_order_stat_order_id` int(11) DEFAULT NULL,
                UNIQUE KEY id (id)
            );";
            require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
            dbDelta($sql);
            
        }else{
             /** Alters*/
             // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching	
            $columns = $wpdb->get_col("DESCRIBE `$table_name`", 0);
            // Add 'canceled_at' column if it doesn't exist
            if (!in_array('canceled_at', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` ADD canceled_at timestamp NULL DEFAULT NULL");
            }
            // Ensure 'status' column has the correct enum values
            if (in_array('status', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` MODIFY COLUMN status enum('new','request_pickup','pending','finished','shipped','return','returned','rejected','canceled') NOT NULL DEFAULT 'new'");
            }
            // Add 'discount_amount' column if it doesn't exist
            if (!in_array('discount_amount', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` ADD discount_amount double DEFAULT NULL");
            }
            // Add 'discount_percentage' column if it doesn't exist
            if (!in_array('discount_percentage', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` ADD discount_percentage double DEFAULT NULL");
            }
            if (!in_array('woocommerce_discount_amount', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` ADD woocommerce_discount_amount decimal(15,2) NOT NULL DEFAULT 0");
            }
            if (!in_array('woocommerce_discount_description', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` ADD woocommerce_discount_description varchar(255) DEFAULT NULL");
            }
            if (!in_array('is_deficit', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` ADD is_deficit tinyint(1) NOT NULL DEFAULT 0");
            }
            if (!in_array('cod_minimum', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` ADD cod_minimum decimal(15,2) DEFAULT NULL");
            }
            if (!in_array('is_printed', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` ADD is_printed tinyint(1) NOT NULL DEFAULT 0");
            }
            if (!in_array('printed_at', $columns)) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration: one-time schema modification, no caching needed
                $wpdb->query("ALTER TABLE `$table_name` ADD printed_at timestamp NULL DEFAULT NULL");
            }
            
        }
        /** Alters*/
    }
    
    private function paymentsTable(){
        global $wpdb;
        /** Payments Table*/
        $suffix     = preg_replace( '/[^a-zA-Z0-9_]/', '', (string) $this->suffix );
        $table_name = esc_sql( $wpdb->prefix . 'kiriminaja_payments' . $suffix );
        
        /** Only create table if not exist */
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) !== $table_name ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
            $sql = "CREATE TABLE `" . $table_name . "`(
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            `pickup_number` varchar(100) DEFAULT NULL,
            `status` enum('paid','unpaid') DEFAULT NULL,
            `method` varchar(50) DEFAULT NULL,
            `order_amt` int(11) DEFAULT 1,
            `pickup_schedule` timestamp NULL DEFAULT NULL,
            `created_at` timestamp NULL DEFAULT NULL,
            UNIQUE KEY id (id)
            );";
            require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
        /** Alters*/
    }

    private function regionCacheTables(){
        global $wpdb;

        require_once(ABSPATH . '/wp-admin/includes/upgrade.php');

        $provinces_table  = esc_sql( $wpdb->prefix . 'kiriminaja_provinces' );
        $cities_table     = esc_sql( $wpdb->prefix . 'kiriminaja_cities' );
        $charset_collate  = $wpdb->get_charset_collate();

        $provinces_sql = "CREATE TABLE `" . $provinces_table . "`(
            `id` bigint(20) NOT NULL,
            `name` varchar(191) NOT NULL,
            `updated_at` timestamp NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `name` (`name`)
        ) " . $charset_collate . ";";

        $cities_sql = "CREATE TABLE `" . $cities_table . "`(
            `id` bigint(20) NOT NULL,
            `province_id` bigint(20) NOT NULL,
            `name` varchar(191) NOT NULL,
            `updated_at` timestamp NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `province_id` (`province_id`),
            KEY `name` (`name`)
        ) " . $charset_collate . ";";

        dbDelta($provinces_sql);
        dbDelta($cities_sql);
    }
}
