<?php
namespace KiriminAjaOfficial\Pages;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create Automatically Page Generate
 */
class AdminPost
{
    public function register(){
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }
        if( kiriof_check_woocommerce() ){
            if( empty(self::checkPageExist('checkout')) ){
                self::createPageKiriminaja();
            }else{
                self::updatePage(self::checkPageExist('checkout')->ID,'[woocommerce_checkout]');
                self::setPageCheckoutWoocommerce(self::checkPageExist('checkout')->ID);
            }
            self::ensureTrackingPage();
            if( empty(self::checkPageExist('cart')) ){
                self::createPageCartKiriminaja();
            }else{
                self::updatePage(self::checkPageExist('cart')->ID,'[woocommerce_cart]');
                self::setPageCartWoocommerce(self::checkPageExist('cart')->ID);
            }
            
            self::setLegacyWoocommerceKiriminaja();
            self::setShippingCalculateCartWoocommerce();
            self::setShippingCodEnabled();            
        }
    }
    private function createPageKiriminaja(){
        $kiriof_page_checkout = array(
            'post_title'    => wp_strip_all_tags( 'Checkout' ),
            'post_content'  => '[woocommerce_checkout]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        );
        
        #create page ID
        $pageID = wp_insert_post( $kiriof_page_checkout );
        self::setPageCheckoutWoocommerce( $pageID );     
    }
    private function createPageKiriminajaTracking(){
        $kiriof_page = array(
            'post_title'    => wp_strip_all_tags( 'Tracking' ),
            'post_content'  => '[kiriminaja-tracking-front-page]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        );
        
        #create page ID
        $pageID = wp_insert_post( $kiriof_page );
        if ( ! is_wp_error( $pageID ) && $pageID ) {
            self::setPageTrackingKiriminaja( $pageID );
        }
    }
    private function createPageCartKiriminaja(){
        $kiriof_page = array(
            'post_title'    => wp_strip_all_tags( 'Cart' ),
            'post_content'  => '[woocommerce_cart]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        );
        
        #create page ID
        $pageID = wp_insert_post( $kiriof_page );
        self::setPageCartWoocommerce($pageID);
    } 	
    /**
     * @return boolean
     */
    private function setPageCheckoutWoocommerce($pageID){
        #set Checkout Page Woocommerce
        update_option( 'woocommerce_checkout_page_id', $pageID );
    }
    private function setPageCartWoocommerce($pageID){
        #set Cart Page Woocommerce
        update_option( 'woocommerce_cart_page_id', $pageID );
    }
    private function setPageTrackingKiriminaja($pageID){
        update_option( 'kiriof_tracking_page_id', absint( $pageID ) );
    }
    private function setShippingCodEnabled(){
        $key_woo_cod = 'woocommerce_cod_settings';
        $arr_cod = get_option($key_woo_cod, []); //array
        if ( ! is_array( $arr_cod ) ) {
            $arr_cod = [];
        }

        //set anabled is yes
        $arr_cod['enabled'] = 'yes';
        update_option($key_woo_cod,$arr_cod);

    }
    /**
     * @return object
     */
    private function checkPageExist($slug){
        return get_page_by_path($slug);
    }
    private function getTrackingPageByShortcode(){
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $wpdb->get_row(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type = 'page'
               AND post_status NOT IN ('trash', 'auto-draft')
               AND (
                   post_content LIKE '%[kiriminaja-tracking-front-page%'
                   OR post_content LIKE '%[wp-tracking-front-page%'
               )
             ORDER BY post_status = 'publish' DESC, ID ASC
             LIMIT 1"
        );
    }
    private function ensureTrackingPage(){
        $tracking_page = self::getTrackingPageByShortcode();
        if ( ! empty( $tracking_page->ID ) ) {
            self::setPageTrackingKiriminaja( $tracking_page->ID );
            return;
        }

        $tracking_slug_page = self::checkPageExist( 'tracking' );
        if ( ! empty( $tracking_slug_page->ID ) ) {
            self::updatePage( $tracking_slug_page->ID, '[kiriminaja-tracking-front-page]' );
            self::setPageTrackingKiriminaja( $tracking_slug_page->ID );
            return;
        }

        self::createPageKiriminajaTracking();
    }
    private function updatePage($pageID,$content){
        $args = array(
            'ID'           => $pageID,
            'post_content' => $content,
        );
      
        wp_update_post( $args );
    }
    /** set Legacy Woocommerce Kiriminaja */
    private function setLegacyWoocommerceKiriminaja(){
        global $wpdb;
        #set Legacy Woocommerce Kiriminaja
        $data   = array( 'option_value'=>'no');
        $where  = array( 'option_name' => 'woocommerce_custom_orders_table_enabled' );
        $wpdb->update( $wpdb->prefix . 'options', $data, $where );  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching      
    }
    /** Set Shipping Woocommerce Calculate Shipping Cart */
    private function setShippingCalculateCartWoocommerce(){
        update_option('woocommerce_enable_shipping_calc','yes');
    }
}
